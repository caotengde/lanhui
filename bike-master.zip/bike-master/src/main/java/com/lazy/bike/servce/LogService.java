package com.lazy.bike.servce;

import org.springframework.stereotype.Service;

/**
 * @author LaZY(李志一)
 * @create 2019-03-26 17:12
 */
public interface LogService {
    void save(String log);

}
